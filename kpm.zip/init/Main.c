code Main
    function main()
        print("Hello World!")
    endFunction

endCode