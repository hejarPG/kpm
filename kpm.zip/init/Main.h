header Main
    uses System
    
    functions
        main()

endHeader